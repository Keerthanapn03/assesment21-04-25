const nesArr=[[3,2,1],[4,5,2],[1,6]]
let sortednesArr=nesArr.sort();
console.log("flattenAndSort",nesArr.flat(Infinity));

console.log("===============================");

const expenses = [
    { category: "Food", amount: 120 },
    { category: "Travel", amount: 300 },
    { category: "Food", amount: 80 },
    { category: "Bills", amount: 200 },
{ category: "Travel", amount: 100 },
];



