package Games;

import java.util.Scanner;

public class GameStore {

	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		boolean a=true;
		
		TotalCost games=new TotalCost();
		while(a) {
		System.out.println("1.Call of Warfare-₹1500");
		System.out.println("2.Speed Racers -₹1200");
		System.out.println("3.Mystery Mansion-₹1000");
		System.out.println("4.Pixel Adventure-₹800");
		System.out.println("5.Puzzle Mania-₹500");
		System.out.println("6.Checkout / Exit");
		System.out.println("Enter the game of your choice:");
		int choice=scan.nextInt();
		switch(choice) {
		case 1:{System.out.println("How many copies you'd like to purchase:");
				int copies=scan.nextInt();
				games.game1(copies);
				break;}
		case 2:{System.out.println("How many copies you'd like to purchase:");
				int copies=scan.nextInt();
				games.game2(copies);
				break;}
		case 3:{System.out.println("How many copies you'd like to purchase:");
				int copies=scan.nextInt();
				games.game3(copies);
				break;}
		case 4:{System.out.println("How many copies you'd like to purchase:");
				int copies=scan.nextInt();
				games.game4(copies);
				break;}
		case 5:{System.out.println("How many copies you'd like to purchase:");
				int copies=scan.nextInt();
				games.game5(copies);
				break;}
		case 6:{a=false;
			System.out.println("Thankyou for shopping");

			System.out.println("The total cost is:" +games.total(choice, choice, choice, choice, choice));
				break;}
		default: System.out.println("Invalid Choice,Try again!");
		}
		
		
		}
	
		

	}

}
