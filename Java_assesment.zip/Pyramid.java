package Games;

public class Pyramid {

	public static void main(String[] args) {
		for(int i=1;i<=5;i++) {
			System.out.println();
			for(int j=1;j<=i;j++) {
				System.out.print("*");
				for(int k=0;k<=j;k++) {
					System.out.print("*");
				}
			}
			
		}

	}

}
