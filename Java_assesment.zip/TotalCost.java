package Games;

public class TotalCost {
	
	public int game1(int copies) {
		int result1=1500*copies;
		return result1;
		
	}
	public int game2(int copies) {
		int result2=1200*copies;
		return result2;
	}
	public int game3(int copies) {
		int result3=1000*copies;
		return result3;
	}
	public int game4(int copies) {
		int result4=800*copies;
		return result4;
	}
	public int game5(int copies) {
		int result5=500*copies;
		return result5;
	}
	public int total(int result1,int result2,int result3,int result4,int result5) {
		int sum=result1+result2+result3+result4+result5;
		return sum;
	}
	
	}


