package Games;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=scan.nextInt();
		int i=num;
		int reverse=0;
		int remainder=0;
		while(num>0) {
			remainder=num%10;
			reverse=reverse*10+remainder;
			num/=10;
		}
		if(i==reverse) {
			System.out.println("It is palindrome");
		}
		else {
			System.out.println("It is not a palindrome");
		}

	}

}
